#include "widget.h"
#include <GL/glu.h>
//#include "objloader.h"

Widget::Widget(QWidget *parent)
    : QOpenGLWidget(parent), m_texture(0), m_indexBuffer(QOpenGLBuffer::IndexBuffer)
{
    m_z = -5.0f;
}

Widget::~Widget()
{
}

void Widget::initializeGL()
{
    glEnable(GL_MULTISAMPLE); // сглаживание MSAA вкл
    glEnable(GL_TEXTURE_2D);		// Разрешение наложение текстуры
    glClearDepth(1.0); // Разрешить очистку буфера глубины
    glEnable(GL_DEPTH_TEST); // Разрешить тест глубины
    glDepthFunc(GL_LESS); // Тип теста глубины
    glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST); // Улучшение в вычислении перспективы

    glClearColor(1.0f, 1.0f, 1.0f, 1.0f);

    glEnable(GL_CULL_FACE);

    initShaders();

    loadObj(":/sidor.obj", 1.5, 1.1, 1.9);
    loadObj(":/sidor.obj", 0.5, 0.5, 0.5);
    loadObj(":/sidor.obj", 0.0, 0.0, 0.0);
    loadObj(":/cube2.obj", 1.5, 1.1, 1.9);


}

void Widget::resizeGL(int w, int h)
{
    float aspect = w / (float)h;

    m_projectionMatrix.setToIdentity();
    m_projectionMatrix.perspective(45, aspect, 0.01f, 20.0f);

}

void Widget::paintGL()
{
    for (int i = 0; i < vertexVector.size(); i++)
    {
        m_arrayBuffer.create();
        m_arrayBuffer.bind();
        m_arrayBuffer.allocate(vertexVector[i].constData(), vertexVector[i].size() * static_cast<int>(sizeof(VertexData)));
        m_arrayBuffer.release();

        m_indexBuffer.create();
        m_indexBuffer.bind();
        m_indexBuffer.allocate(indexesVector[i].constData(), indexesVector[i].size() *static_cast<int>(sizeof(GLuint)));
        m_indexBuffer.release();
    }



    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    QMatrix4x4 viewMatrix;
    viewMatrix.setToIdentity();
    viewMatrix.translate(0.0, 0.0, m_z);
    viewMatrix.rotate(m_rotation);

    QMatrix4x4 modelMatrix;
    modelMatrix.setToIdentity();

    m_texture = new QOpenGLTexture(QImage(":/artyom.png").mirrored());
    m_texture->setMinificationFilter(QOpenGLTexture::Nearest);
    m_texture->setMagnificationFilter(QOpenGLTexture::Linear);
    m_texture->setWrapMode(QOpenGLTexture::Repeat);

    m_texture->bind(0);

    m_program.bind();
    m_program.setUniformValue("qt_ModelViewProjectionMatrix", m_projectionMatrix * viewMatrix);
    m_program.setUniformValue("qt_Texture0", 0);

    m_arrayBuffer.bind();

    int offset = 0;

    int vertLoc = m_program.attributeLocation("qt_Vertex");
    m_program.enableAttributeArray(vertLoc);
    m_program.setAttributeBuffer(vertLoc, GL_FLOAT, offset, 3, sizeof(VertexData));

    offset += sizeof(QVector3D);

    int texLoc = m_program.attributeLocation("qt_MultiTexCoord0");
    m_program.enableAttributeArray(texLoc);
    m_program.setAttributeBuffer(texLoc, GL_FLOAT, offset, 2, sizeof(VertexData));

    m_indexBuffer.bind();

    glDrawElements(GL_TRIANGLES, m_indexBuffer.size(), GL_UNSIGNED_INT, 0);
    glDisableClientState(GL_VERTEX_ARRAY);
    glDisableClientState(GL_COLOR_ARRAY);


}

void Widget::mousePressEvent(QMouseEvent *event)
{
    if (event->buttons() == Qt::LeftButton) {
    m_mousePosition = QVector2D(event->localPos());
    }
    event->accept();
}

void Widget::mouseMoveEvent(QMouseEvent *event)
{
    if (event->buttons() == Qt::LeftButton) {

    QVector2D diff = QVector2D(event->localPos()) - m_mousePosition;
    m_mousePosition = QVector2D(event->localPos());

    float angle = diff.length() / 2.0;

    QVector3D axis = QVector3D(diff.y(), diff.x(), 0.0);

    m_rotation = QQuaternion::fromAxisAndAngle(axis, angle) * m_rotation;
    }
    update();
}

void Widget::wheelEvent(QWheelEvent *event)
{
    if(event->angleDelta().y() > 0) {
        m_z += 0.5f;
    }else if (event->angleDelta().y() < 0){
        m_z -= 0.5f;
    }
    if (m_z <= -10 ){
        //loadObj(":/cube2.obj", 2, 2, 2);
        delObj(1.5, 1.1, 1.9);
    }

    qDebug() <<  m_z;
    update();
}

void Widget::initShaders()
{
    if (!m_program.addShaderFromSourceFile(QOpenGLShader::Vertex, ":/vshader.vsh"))
        close();

    if (!m_program.addShaderFromSourceFile(QOpenGLShader::Fragment, ":/fshader.fsh"))
        close();

    if (!m_program.link())
        close();
}

void Widget::initCube(float width)
{
    float width_div_2 = width / 2.0f;
    QVector<VertexData> vertexes;
    vertexes.append(VertexData(QVector3D(-width_div_2, width_div_2, width_div_2),
                               QVector2D(0.0, 1.0), QVector3D(0.0,0.0,1.0)));
    vertexes.append(VertexData(QVector3D(-width_div_2, -width_div_2, width_div_2),
                               QVector2D(0.0, 0.0), QVector3D(0.0,0.0,1.0)));
    vertexes.append(VertexData(QVector3D(width_div_2, width_div_2, width_div_2),
                               QVector2D(1.0, 1.0), QVector3D(0.0,0.0,1.0)));
    vertexes.append(VertexData(QVector3D(width_div_2, -width_div_2, width_div_2),
                               QVector2D(1.0, 0.0), QVector3D(0.0,0.0,1.0)));

    vertexes.append(VertexData(QVector3D(width_div_2, width_div_2, width_div_2),
                               QVector2D(0.0, 1.0), QVector3D(1.0,0.0,0.0)));
    vertexes.append(VertexData(QVector3D(width_div_2, -width_div_2, width_div_2),
                               QVector2D(0.0, 0.0), QVector3D(1.0,0.0,0.0)));
    vertexes.append(VertexData(QVector3D(width_div_2, width_div_2, -width_div_2),
                               QVector2D(1.0, 1.0), QVector3D(1.0,0.0,0.0)));
    vertexes.append(VertexData(QVector3D(width_div_2, -width_div_2, -width_div_2),
                               QVector2D(1.0, 0.0), QVector3D(1.0,0.0,0.0)));

    vertexes.append(VertexData(QVector3D(width_div_2, width_div_2, width_div_2),
                               QVector2D(0.0, 1.0), QVector3D(0.0,1.0,0.0)));
    vertexes.append(VertexData(QVector3D(width_div_2, width_div_2, -width_div_2),
                               QVector2D(0.0, 0.0), QVector3D(0.0,1.0,0.0)));
    vertexes.append(VertexData(QVector3D(-width_div_2, width_div_2, width_div_2),
                               QVector2D(1.0, 1.0), QVector3D(0.0,1.0,0.0)));
    vertexes.append(VertexData(QVector3D(-width_div_2, width_div_2, -width_div_2),
                               QVector2D(1.0, 0.0), QVector3D(0.0,1.0,0.0)));

    vertexes.append(VertexData(QVector3D(width_div_2, width_div_2, -width_div_2),
                               QVector2D(0.0, 1.0), QVector3D(0.0,0.0,-1.0)));
    vertexes.append(VertexData(QVector3D(width_div_2, -width_div_2, -width_div_2),
                               QVector2D(0.0, 0.0), QVector3D(0.0,0.0,-1.0)));
    vertexes.append(VertexData(QVector3D(-width_div_2, width_div_2, -width_div_2),
                               QVector2D(1.0, 1.0), QVector3D(0.0,0.0,-1.0)));
    vertexes.append(VertexData(QVector3D(-width_div_2, -width_div_2, -width_div_2),
                               QVector2D(1.0, 0.0), QVector3D(0.0,0.0,-1.0)));

    vertexes.append(VertexData(QVector3D(-width_div_2, width_div_2, width_div_2),
                               QVector2D(0.0, 1.0), QVector3D(-1.0,0.0,0.0)));
    vertexes.append(VertexData(QVector3D(-width_div_2, width_div_2, -width_div_2),
                               QVector2D(0.0, 0.0), QVector3D(-1.0,0.0,0.0)));
    vertexes.append(VertexData(QVector3D(-width_div_2, -width_div_2, width_div_2),
                               QVector2D(1.0, 1.0), QVector3D(-1.0,0.0,0.0)));
    vertexes.append(VertexData(QVector3D(-width_div_2, -width_div_2, -width_div_2),
                               QVector2D(1.0, 0.0), QVector3D(-1.0,0.0,0.0)));

    vertexes.append(VertexData(QVector3D(-width_div_2, -width_div_2, width_div_2),
                               QVector2D(0.0, 1.0), QVector3D(0.0,-1.0,0.0)));
    vertexes.append(VertexData(QVector3D(-width_div_2, -width_div_2, -width_div_2),
                               QVector2D(0.0, 0.0), QVector3D(0.0,-1.0,0.0)));
    vertexes.append(VertexData(QVector3D(width_div_2, -width_div_2, width_div_2),
                               QVector2D(1.0, 1.0), QVector3D(0.0,-1.0,0.0)));
    vertexes.append(VertexData(QVector3D(width_div_2, -width_div_2, -width_div_2),
                               QVector2D(1.0, 0.0), QVector3D(0.0,-1.0,0.0)));

    QVector<GLuint> indexes;
    for (int i = 0; i < 24; i += 4)
    {
        indexes.append(i + 0);
        indexes.append(i + 1);
        indexes.append(i + 2);
        indexes.append(i + 2);
        indexes.append(i + 1);
        indexes.append(i + 3);
    }

    m_arrayBuffer.create();
    m_arrayBuffer.bind();
    m_arrayBuffer.allocate(vertexes.constData(), vertexes.size() * sizeof(VertexData));
    m_arrayBuffer.release();

    m_indexBuffer.create();
    m_indexBuffer.bind();
    m_indexBuffer.allocate(indexes.constData(), indexes.size() * sizeof(GLuint));
    m_indexBuffer.release();

    m_texture = new QOpenGLTexture(QImage(":/bricks.jpg").mirrored());
    // set nearest filtering mode for texture minification
    m_texture->setMinificationFilter(QOpenGLTexture::Nearest);
    // set bilinear filtering mode for texture magnification
    m_texture->setMagnificationFilter(QOpenGLTexture::Linear);
    // wrap texture coordinates by repeating
    // f.ex texture coordinate (1.1, 1.2) is same as (0.1, 0.2)
    m_texture->setWrapMode(QOpenGLTexture::Repeat);
}

void Widget::loadObj(const QString &path, float x, float y, float z)
{
    QFile objFile(path);
    if (!objFile.exists()){
        qDebug() << "File not found!";
        return;
    }
    objFile.open(QIODevice::ReadOnly);
    QTextStream input(&objFile);



    std::vector<std::string> coord;

    QVector<QVector3D> vertex;
    QVector<QVector2D> uvs;
    QVector<QVector3D> normals;
    QVector<face> faces;

    qDebug() << "Reading" << path << "...";

    while(!input.atEnd())
    {
        QString str = input.readLine();
        if(str.isEmpty()) continue;
        QStringList list = str.split(" ");
        list.removeAll(" ");

            if(list[0] != '#')
            {
                if (list[0] == "v") // если вершина
                {
                    float tmpx,tmpy,tmpz;
                    tmpx = list[1].toFloat() + x;
                    tmpy = list[2].toFloat() + y;
                    tmpz = list[3].toFloat() + z;
                    vertex.push_back(QVector3D(tmpx,tmpy,tmpz));
                } else if (list[0] == "vn") // если нормаль
                {
                    float tmpx,tmpy,tmpz;
                    tmpx = list[1].toFloat();
                    tmpy = list[2].toFloat();
                    tmpz = list[3].toFloat();
                    normals.push_back(QVector3D(tmpx,tmpy,tmpz));

                } else if (list[0] == "vt") // если текстурная вершина
                {
                    float tmpx,tmpy;
                    tmpx = list[1].toFloat();
                    tmpy = list[2].toFloat();
                    uvs.push_back(QVector2D(tmpx,tmpy));
                } else if(list[0]== "f")     // если грань
                {
                    if (uvs.size() == 0){
                        for (int i = 0; i < 5; i ++){
                            uvs.push_back(QVector2D(0.0, 0.0));
                        }
                    }
                    bool ok = true;
                    for (int q = 1; q < 4; q++)
                    {
                        auto vv = list[q].split('/');
                        vertexes.append(VertexData(vertex.at(vv.at(0).toInt(&ok, 10) - 1), uvs.at(vv.at(1).toInt(&ok, 10) - 1), normals.at(vv.at(2).toInt(&ok, 10) - 1)));
                        indexes.append(indexes.size());
                    }
                }
            }            
    }


    vertexVector.push_back(vertexes);
    indexesVector.push_back(indexes);
    coorObj.push_back(QVector3D(x,y,z));

    normals.clear();
    uvs.clear();



//    m_texture = new QOpenGLTexture(QImage(":/illusion.jpg").mirrored());
//    // set nearest filtering mode for texture minification
//    m_texture->setMinificationFilter(QOpenGLTexture::Nearest);
//    // set bilinear filtering mode for texture magnification
//    m_texture->setMagnificationFilter(QOpenGLTexture::Linear);
//    // wrap texture coordinates by repeating
//    // f.ex texture coordinate (1.1, 1.2) is same as (0.1, 0.2)
//    m_texture->setWrapMode(QOpenGLTexture::Repeat);

        objFile.close();
        qDebug() <<  "... done";
}

void Widget::delObj(float x, float y, float z){
    int numObj = - 1;
    for (int i = 0; i < coorObj.size(); i++)
    {
        numObj = i;
    }
    vertexVector[numObj].clear();
    update();
}


