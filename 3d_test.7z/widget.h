#ifndef WIDGET_H
#define WIDGET_H

#include <QOpenGLWidget>
#include <QMatrix4x4>
#include <QtOpenGL>
#include <QOpenGLShaderProgram>
#include <QOpenGLBuffer>
#include <QOpenGLTexture>
#include <QImage>
#include <QVector>
//#include <glm/vec2.hpp>
//#include <glm/vec3.hpp>
//#include <GL/glext.h>

//#include <gl.h>

//#include <GlBufferData>

struct VertexData
{
    VertexData() {}
    VertexData(QVector3D p, QVector2D t, QVector3D n)
        : position(p), texCoords(t), normals(n) {}
    QVector3D position;
    QVector2D texCoords;
    QVector3D normals;
};

struct face // грань
{
    struct vertex { // вершина
        GLuint v_i; // индекс вершины
        GLuint vt_i; // индекс текстурной вершины
        GLuint vn_i; // индекс вершины нормали
    };

    vertex v[3]; // три вершины у треугольника - полигона

    face(vertex v1,vertex v2,vertex v3) // полигон (грань)
    {
        v[0]=v1;
        v[1]=v2;
        v[2]=v3;
    }
};

class Widget : public QOpenGLWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();

protected:
    GLubyte model_count = 0; // номер текущей модели
    GLuint model; // номер display list для вывода нужной модели

    void initializeGL() override;
    void resizeGL(int w, int h) override;
    void paintGL() override;

    void mousePressEvent(QMouseEvent *event) override;
    void mouseMoveEvent(QMouseEvent *event) override;
    void wheelEvent(QWheelEvent *event) override;

    void initShaders();
    void initCube(float width);
    int loadObject(const QString &filename);

    GLuint drawCube(); // нарисовать куб
    void loadObj(const QString &path, float x, float y, float z);
    void delObj(float x, float y, float z);
//    bool loadOBJ(const char * path,
//                 std::vector < glm::vec3 > & out_vertices,
//                 std::vector < glm::vec2 > & out_uvs,
//                 std::vector < glm::vec3 > & out_normals
//             );
//    enum target{};
//    enum usage{};
//    void glBufferData(enum target(), glm::vec3 size, const void *data, enum usage());

private:
    QMatrix4x4 m_projectionMatrix;
    QOpenGLShaderProgram m_program;
    QOpenGLTexture *m_texture;
    QOpenGLBuffer m_arrayBuffer;

    QOpenGLBuffer m_indexBuffer;

    QVector<QVector<VertexData>> vertexVector;
    QVector<VertexData> vertexes;
    QVector<QVector<GLuint>> indexesVector;
    QVector<GLuint> indexes;
    QVector<QVector3D> coorObj;

    QVector2D m_mousePosition;
    QQuaternion m_rotation;
    float aspect;

    float m_z;
};
#endif // WIDGET_H
